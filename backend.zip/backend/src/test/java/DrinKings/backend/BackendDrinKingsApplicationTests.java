package DrinKings.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendDrinKingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
